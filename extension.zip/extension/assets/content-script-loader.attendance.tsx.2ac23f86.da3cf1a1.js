(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.2ac23f86.js")
    );
  })().catch(console.error);

})();
