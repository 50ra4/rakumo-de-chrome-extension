(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.8d560939.js")
    );
  })().catch(console.error);

})();
