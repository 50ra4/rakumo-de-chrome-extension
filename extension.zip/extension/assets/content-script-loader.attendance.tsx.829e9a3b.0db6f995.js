(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.829e9a3b.js")
    );
  })().catch(console.error);

})();
