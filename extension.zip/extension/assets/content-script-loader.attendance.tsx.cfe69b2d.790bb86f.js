(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.cfe69b2d.js")
    );
  })().catch(console.error);

})();
