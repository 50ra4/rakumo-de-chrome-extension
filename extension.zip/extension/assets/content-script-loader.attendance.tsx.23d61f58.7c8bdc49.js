(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.23d61f58.js")
    );
  })().catch(console.error);

})();
