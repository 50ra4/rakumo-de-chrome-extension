(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/attendance.tsx.b2ca1d7a.js")
    );
  })().catch(console.error);

})();
