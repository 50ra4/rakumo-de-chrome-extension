(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content_script.tsx.97a14075.js")
    );
  })().catch(console.error);

})();
